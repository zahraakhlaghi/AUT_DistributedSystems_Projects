package distributedSystem;

public interface Remote {

}
